<?php

require __DIR__.'/vendor/autoload.php';

var_dump($_SERVER);


